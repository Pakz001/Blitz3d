Blue (c) 2004 by R.v.Etten

This code may be used in freeware and open source tools only.

; Current Implementations :
;								Ctrl + Page Down
;								Alt+F4
;								Data array adjusts to size of text file.
;								Mouse press aligns cursor (single/multi line)
;								Line numbering (optional and dynamic) / Buffered
;								Del
;								Commandline file loading (limited to 40 lines 72 chars wide)
;								Mouse Line Select
;								Backspace
;								Home
;								End
;								Ctrl + Cursor Right
;								Ctrl + Cursor Left
;								Shift + Cursor Right
;								Shift + Cursor Left
;								Shift + Ctrl + Cursor Right
;								Shift + Ctrl + Cursor Left
;								Page Up
;								Page Down 
;								Ctrl + Home
;								Ctrl + End
;								Cursor Up
;								Cursor Down
;								Enter/Return
;								Ctrl + C (Single line)
;								Ctrl + V (Single Line)
;								Loadtext
;								Insert/Overwrite
;								Insert/Overwrite cursor
;								Single line Tab insert (non structured)
;								Adjusts to startup resolution
;
; Todo :
;								Bugs!!! :
;								Fix addition to cursor on line mouse exit
;								Fix Mouse line/row selection (line gets reset to zero, check collision)
;
;								Special Edit (vertical Selection)
;								Shift + Tab
;								Internal Tab handling
;								Multiple Line Select
;								Tab Multiple Lines
;								Shift + Tab multiple Lines + optimalization
;								Ctrl + C (Multi line)
;								Ctrl + V (Multi line)
;								Ctrl + X (Single Line/Multi line)
;								Italic/Bold/Underline
;								Enter + Splitline
;								Mouse to Character collision
;								Mouse Selection Automation
;								Text Folding
;								Folding interface + Hotkeys
;								Colored Text
;								Inline Icons
;								Popup menu
;								Auto Completion (list or shaded preview)
;								Current Line expand to Visual console
;								Horizontal and Vertical Scrollbars
;								Data structure optimalization
;								Config file based Parsing system
;								Save Text
;								Sorting routines
;								Find/Replace core routines
;								Double click keys (Ctrl/shift/Alt)
;								Font support
;								Dynamic multiple font support
;								Inline Images or Ontop Images
;								Edit Statistics
;								Text Statistics
;								Image Buffering
								Adjusts to startup resolution
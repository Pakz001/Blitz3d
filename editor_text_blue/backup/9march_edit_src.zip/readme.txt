Blue (c) 2004 by R.v.Etten

This code may be used in freeware and open source tools only.

; Current Implementations :
;								Line numbering (optional and dynamic) / Buffered
;								Del
;								Commandline file loading (limited to 40 lines 72 chars wide)
;								Mouse Line Select
;								Backspace
;								Home
;								End
;								Ctrl + Cursor Right
;								Ctrl + Cursor Left
;								Shift + Cursor Right
;								Shift + Cursor Left
;								Shift + Ctrl + Cursor Right
;								Shift + Ctrl + Cursor Left
;								Page Up (partially)
;								Page Down (partially)
;								Ctrl + Home
;								Ctrl + End
;								Cursor Up
;								Cursor Down
;								Enter/Return
;								Ctrl + C (Single line)
;								Ctrl + V (Single Line)
;								Loadtext
;								Insert/Overwrite
;								Insert/Overwrite cursor
;								Single line Tab insert (non structured)
;								Adjusts to startup resolution